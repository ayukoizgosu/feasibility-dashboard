# Antigravity Delegator

A hybrid agent workflow with two Builders: **Gemini CLI** and **Codex CLI**.

## Quick Start

1. Copy context files (`GEMINI.md`, `CODEX.md`) to your project root
2. Copy `quality_gate.py` to your project root  
3. Add `ARCHITECT_RULES.md` content to your Antigravity settings

## How It Works

```
User Request → Claude Plans → Gemini/Codex Writes → Quality Gate → Done
```

| Role | Tool | Purpose |
|------|------|---------|
| **Architect** | Claude Opus | Planning, reasoning, verification |
| **Builder 1** | Gemini CLI | General code generation |
| **Builder 2** | Codex CLI | Complex logic, backup |

## Files

| File | Description |
|------|-------------|
| `GEMINI.md` | Context file for Gemini CLI |
| `CODEX.md` | Context file for Codex CLI |
| `quality_gate.py` | Validates Builder output |
| `ARCHITECT_RULES.md` | Paste into Antigravity settings |
| `hud/` | Quota monitoring dashboard |

